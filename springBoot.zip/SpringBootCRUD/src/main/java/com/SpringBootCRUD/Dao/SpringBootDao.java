package com.SpringBootCRUD.Dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.SpringBootCRUD.Entity.User;

@Repository
public class SpringBootDao {

	@Autowired
	SessionFactory sf;

	public String insertOneUser(User obj) {
		Session ses = sf.openSession();
		Transaction tr = ses.beginTransaction();
		ses.save(obj);
		tr.commit();
		ses.close();
		return "User inserted...!";
	}

	public String insertListOfUser(List<User> list) {
		Session ses = sf.openSession();
		Transaction tr = ses.beginTransaction();
		for (User user : list) {
			ses.save(user);
		}
		tr.commit();
		ses.close();
		return "List Inserted....!";
	}

	public String updateOneUser(User obj) {
		Session ses = sf.openSession();
		Transaction tr = ses.beginTransaction();
		ses.update(obj);
		tr.commit();
		ses.close();
		return "User Updated....!";
	}

	public String UpdateListOfUser(List<User> list) {
		Session ses = sf.openSession();
		Transaction tr = ses.beginTransaction();
		for (User user : list) {
			ses.update(user);
		}
		return "List Updated....!";
	}

	public User fetchOneUser(int id) {
		Session ses = sf.openSession();
		User ss = ses.get(User.class, id);
		ses.close();
		return ss;
	}
	
	public User loadOneUser(int id) {
		Session ses = sf.openSession();
		User ss = ses.load(User.class, id);
		ses.close();
		return ss;
	}

	public List<User> fetchListOfUser() {
		Session ses = sf.openSession();
		Criteria cry = ses.createCriteria(User.class);
		List<User> list = cry.list();
		return list;
	}
}
