package com.SpringBootCRUD.Entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class User {

	@Id
	private int userId;
	private String userFristName;
	private String userLastName;
	private long mobileNumber;
	private String email;
	private String password;
	
	public User() {
		super();
	}

	/**
	 * @param userId
	 * @param userFristName
	 * @param userLastName
	 * @param mobileNumber
	 * @param email
	 * @param password
	 */
	public User(int userId, String userFristName, String userLastName, long mobileNumber, String email,
			String password) {
		super();
		this.userId = userId;
		this.userFristName = userFristName;
		this.userLastName = userLastName;
		this.mobileNumber = mobileNumber;
		this.email = email;
		this.password = password;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserFristName() {
		return userFristName;
	}

	public void setUserFristName(String userFristName) {
		this.userFristName = userFristName;
	}

	public String getUserLastName() {
		return userLastName;
	}

	public void setUserLastName(String userLastName) {
		this.userLastName = userLastName;
	}

	public long getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "User => userId =" + userId + ", userFristName =" + userFristName + ", userLastName =" + userLastName
				+ ", mobileNumber =" + mobileNumber + ", email =" + email + ", password =" + password;
	}
	
	
}
