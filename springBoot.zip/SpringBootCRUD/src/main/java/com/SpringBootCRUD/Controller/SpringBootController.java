package com.SpringBootCRUD.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.SpringBootCRUD.Entity.User;
import com.SpringBootCRUD.Service.SpringBootService;

@RestController
public class SpringBootController {

	@Autowired
	SpringBootService ss;

	@PostMapping("/postone")
	public String insertOneUser(@RequestBody User obj) {
		String msg= ss.insertOneUser(obj);
		return msg;
	}
	@PostMapping("/postlist")
	public String insertListOfUser(@RequestBody List<User> list) {
		String msg=ss.insertListOfUser(list);
		return msg;
	}
	@PutMapping("/updateone")
	public String updateOneUser(@RequestBody User obj) {
		String msg=ss.updateOneUser(obj);
		return msg;
	}

	@PutMapping("/updatelist")
	public String UpdateListOfUser(@RequestBody List<User> list) {
		String msg=ss.UpdateListOfUser(list);
		return msg;
	}
	@GetMapping("/getone/{id}")
	public User fetchOneUser(@PathVariable int id) {
		User s1=ss.fetchOneUser(id);
		return s1;
	}
	@GetMapping("/getload/{id}")
	public User loadOneUser(@PathVariable int id) {
		User load=ss.loadOneUser(id);
		return load;
	}
	@GetMapping("/getlist")
	public List<User> fetchListOfUser() {
		List<User> list= ss.fetchListOfUser();
		return list;
	}
	
}
