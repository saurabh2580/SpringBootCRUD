package com.SpringBootCRUD.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.SpringBootCRUD.Dao.SpringBootDao;
import com.SpringBootCRUD.Entity.User;

@Service
public class SpringBootService {

	@Autowired
	SpringBootDao sd;

	public String insertOneUser(User obj) {
		String msg = sd.insertOneUser(obj);
		return msg;
	}
	
	public String insertListOfUser(List<User> list) {
		String msg=sd.insertListOfUser(list);
		return msg;
	}
	
	public String updateOneUser(User obj) {
		String msg=sd.updateOneUser(obj);
		return msg;
	}

	public String UpdateListOfUser(List<User> list) {
		String msg=sd.UpdateListOfUser(list);
		return msg;
	}
	
	public User fetchOneUser(int id) {
		User ss=sd.fetchOneUser(id);
		return ss;
	}
	public User loadOneUser(int id) {
		User load=sd.loadOneUser(id);
		return load;
	}
	
	public List<User> fetchListOfUser() {
		List<User> list= sd.fetchListOfUser();
		return list;
	}
	
	

	

		
		
		
		
		
		
		
		
		
		
		
}